package Bad;

use strict;
use warnings;

sub Bad { 'Bad' }
