package DirectNestedUnimport;

use strict;
use warnings;

use true;
use true;

{
    no true;
    no true;
}
