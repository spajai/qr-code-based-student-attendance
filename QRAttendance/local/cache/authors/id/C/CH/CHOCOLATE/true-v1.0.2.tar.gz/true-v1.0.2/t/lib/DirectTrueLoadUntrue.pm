package DirectTrueLoadUntrue;

use strict;
use warnings;
use true;

use Untrue1;

sub whatever { 'whatever' }
