package Good;

use strict;
use warnings;

use Contemporary::Perl;

sub Good { 'Good' };
