package GoodWithSubclass;

use strict;
use warnings;

use Contemporary::Perl::Subclass;

sub Good { 'GoodWithSubclass' }
