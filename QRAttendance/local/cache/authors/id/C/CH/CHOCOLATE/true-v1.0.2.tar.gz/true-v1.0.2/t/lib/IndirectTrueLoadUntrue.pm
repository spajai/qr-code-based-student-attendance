package IndirectTrueLoadUntrue;

use strict;
use warnings;

use Contemporary::Perl::Subclass::Subclass;
use Untrue2;

sub whatever { 'whatever' }
