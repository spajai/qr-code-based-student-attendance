package TestSubclass;

use Contemporary::Perl::Subclass;

sub Foo { 'Foo' };

0;

=head1 NAME

TestSubclass

=item 1 Blah

=cut
