package Untrue1;

use strict;
use warnings;

sub whatever { 'whatever' }
