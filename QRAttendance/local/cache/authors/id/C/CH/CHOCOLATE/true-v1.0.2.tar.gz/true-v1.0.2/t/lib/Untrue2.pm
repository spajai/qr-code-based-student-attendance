package Untrue2;

use strict;
use warnings;

sub whatever { 'whatever' }
