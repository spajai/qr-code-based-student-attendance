#!/usr/bin/env perl

use strict;
use warnings;

sub bad { 'bad' };
