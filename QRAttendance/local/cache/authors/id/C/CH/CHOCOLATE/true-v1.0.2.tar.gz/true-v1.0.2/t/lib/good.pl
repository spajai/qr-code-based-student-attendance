#!/usr/bin/env perl

use Contemporary::Perl;

sub good { 'good' };
