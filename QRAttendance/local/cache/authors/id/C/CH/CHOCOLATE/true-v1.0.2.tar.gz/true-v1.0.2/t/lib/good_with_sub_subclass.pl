#!/usr/bin/env perl

use Contemporary::Perl::Subclass::Subclass;

sub good_with_sub_subclass { 'good_with_sub_subclass' };
