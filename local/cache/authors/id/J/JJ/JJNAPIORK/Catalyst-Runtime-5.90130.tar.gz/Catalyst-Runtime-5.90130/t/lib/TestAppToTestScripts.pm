package TestAppToTestScripts;
use strict;
use warnings;
use Carp;

our @RUN_ARGS;

sub run {
    @RUN_ARGS = @_;
    1; # Does this work?
}

1;

