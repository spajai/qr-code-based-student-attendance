#ifndef _SCRYPT_PLATFORM_H_
#define _SCRYPT_PLATFORM_H_

#endif /* !_SCRYPT_PLATFORM_H_ */
